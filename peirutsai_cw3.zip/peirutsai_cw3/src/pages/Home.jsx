import React from 'react';
import Navbar from '../components/Navbar.jsx';
import B1 from '../components/B1.jsx';
import Occasion from '../components/Occasion.jsx';
import Diet from '../components/Diet.jsx';
import Taiwan from '../components/Taiwan.jsx';
import Category from '../components/Category.jsx';
import Footer from '../components/Footer.jsx';


const Home = () => {
  return (
    <div>
     <Navbar/>
     <B1/>
     <Occasion/>
     <Category/>
     <Diet/>
     <Taiwan/>
     <Footer/>
    </div>
  )
}

export default Home;
