import React from 'react';
import { Route, Routes, useLocation,} from 'react-router-dom';
import {AnimatePresence} from 'framer-motion';

import Home from './pages/Home.jsx';
import Recipe from './pages/Recipe.jsx';
import Searched from './pages/Searched.jsx';
import Cuisine from './pages/Cuisine.jsx';
import Specialdiet from './pages/Specialdiet.jsx';
import Weeklyarticle from './pages/Weeklyarticle.jsx';
import About from './pages/About.jsx';


function App() {
  const location = useLocation();
  return (

    <AnimatePresence exitBeforeEnter>
       <Routes Location={location} key={location.pathname}>
         <Route path='/' element={<Home/>}/>
         <Route path='/Cuisine/:type' element={<Cuisine/>}/>
         <Route path='/Specialdiet/:type' element={<Specialdiet/>}/>
         <Route path='/Searched/:search' element={<Searched/>}/>
         <Route path='/Recipe/:name' element={<Recipe/>}/>
         <Route path='/Weeklyarticle' element={<Weeklyarticle/>}/>
         <Route path='/About' element={<About/>}/>
       </Routes>
    </AnimatePresence>

  );
}

export default App;
