import React from 'react';
import image1 from '../assets/feedbackphoto01.jpg';
import image2 from '../assets/feedbackphoto02.jpg';
import image3 from '../assets/feedbackphoto03.jpg';
import image4 from '../assets/feedbackphoto04.jpg';
import image5 from '../assets/feedbackphoto05.jpg';
import image6 from '../assets/feedbackphoto06.jpg';
import image7 from '../assets/feedbackphoto07.jpg';
import image8 from '../assets/feedbackphoto08.jpg';
import image9 from '../assets/feedbackphoto09.jpg';
import image10 from '../assets/feedbackphoto10.jpg';



export default [image1,image2, image3, image4,image5,image6,image7,image8,image9,image10];
