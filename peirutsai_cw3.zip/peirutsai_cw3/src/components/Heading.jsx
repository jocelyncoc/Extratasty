import React from 'react';
import '../components/Headingstyle.css'


const Heading = () => {
  return (
    <div className='headingtop'>
    <div className='title'>
     <p><span>/ Weekly Foodie Article /</span></p>
     <h1>Cuisine in Taiwan</h1>
     <h3>Three must try restaurants with extraordinary expereinces</h3>


    </div>
    </div>
  )
}

export default Heading;
